﻿namespace simuladorpatos
{
    interface Interface_pato_dev
    {
        void codando();


    }
}
