﻿namespace simuladorpatos
{
    interface interface_pato_luz
    {
        void Brilhar();
        void voar();
        void grasnar();


    }
}
