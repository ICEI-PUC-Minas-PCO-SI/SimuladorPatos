﻿namespace simuladorpatos
{
    interface Interface_pato_maluco
    {
        void latir();
        void dancar();
        void voar();


    }
}
